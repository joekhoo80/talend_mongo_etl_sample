package routines.system;

public interface IPersistableComparableLookupRow<R> extends IPersistableLookupRow<R>, Comparable<R> {

}
